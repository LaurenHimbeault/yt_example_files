import java.util.ArrayList;

public class BinaryConvert {
	public static void main(String[] args) {
		ArrayList<Integer> binayRep = convertToBinary(2);
		System.out.println(binayRep);
	}

	public static ArrayList<Integer> convertToBinary(int baseTenN) {
		if(baseTenN == 0) {
			return new ArrayList<Integer> ();
		} else {
			ArrayList<Integer> arr = convertToBinary(baseTenN/2);
			arr.add(baseTenN%2);
			return arr;
		}
	}
}