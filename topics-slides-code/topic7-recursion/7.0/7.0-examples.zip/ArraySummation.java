public class ArraySummation {
	public static void main(String[] args) {
		int[] data = {};
		int sum = sumOf(data);
		System.out.println(sum);
	}

	public static int sumOf(int[] data) {
		return sumOfR(data, data.length);
	}

	private static int sumOfR(int[] data, int n) {
		if (n == 0) { return 0; }
		else {
			return data[n-1] + sumOfR(data, n-1);
		}
	}
}