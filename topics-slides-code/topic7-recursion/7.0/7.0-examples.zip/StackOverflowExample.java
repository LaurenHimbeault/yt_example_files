public class StackOverflowExample {
	public static void main(String[] args) {
			// iterativeInfinity();
			recursiveInfinity(0);
		
	}
	public static void iterativeInfinity() {
		int i = 0;

		while(true) {
			if(i < 0) { 
				break; 
			} else {
				i--;
			}
			i++;
			System.out.println(i);

		}
	}
	public static void recursiveInfinity(int n) {
		System.out.println(n);
		if(n >= 0) {
			recursiveInfinity(n+1);
		}
	}
}
