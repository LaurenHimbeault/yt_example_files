public class LinearSearch {
	public static void main(String[] args) {
		int[] arr = {3,5,6,2,9,11,-9,4};
		int target = 9;
		int foundIndex = linear(arr, target);
		System.out.println(foundIndex);
	}

	// returns the index of the target in arr or -1 if it does not exist
	public static int linear(int[] arr, int target) {
		int index = -1;
		int posn = 0;
		while(posn < arr.length && index < 0) {
			if(arr[posn] == target) {
				index = posn;
			}
			posn++;
		}
		return index;
	}
}





