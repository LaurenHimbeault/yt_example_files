public class BinarySearch {
		public static void main(String[] args) {
		int[] arr = {-9,2,3,4,5,6,9,11};
		int target = 9;
		int foundIndex = binary(arr, target);
		System.out.println(foundIndex);
	}
	public static int binary(int[] arr, int target) {
		int lo = 0;
		int hi = arr.length;
		int mid = (int)Math.floor((hi + lo)/2);
		int foundIndex = -1;
		while(lo < hi && foundIndex < 0) {
			if(arr[mid] == target){
				foundIndex = mid;
			}
			else if (arr[mid] < target) {
				lo = mid + 1;
			}
			else {
				hi = mid;
			}
			mid = (int)Math.floor((hi + lo)/2);
		}
		return foundIndex;
	}
}




