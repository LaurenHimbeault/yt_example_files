public class OrderedInsert {
    public static void main(String[] args) {
        // Example usage
        int[] array = {10, 20, 30, 40, 50, 0}; // Last element is empty for the new value
        int valueToInsert = 35;

        orderedInsert(array, valueToInsert);

        // Print the updated array
        for (int value : array) {
            System.out.print(value + " ");
        }
    }

    public static void orderedInsert(int[] array, int value) {
        int position = array.length - 2; // Start from the second last element

        // Move elements over to the right
        while (position >= 0 && array[position] > value) {
            array[position + 1] = array[position];
            position--;
        }

        // Insert the new value
        array[position + 1] = value;
    }
}
