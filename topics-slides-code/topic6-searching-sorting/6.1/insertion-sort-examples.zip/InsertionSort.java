public class InsertionSort {
    public static void main(String[] args) {
        // Example usage
        int[] array = {40, 20, 30, 50}; 

        // Print the updated array
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();

        for(int i = 1; i < array.length; i++) {
            System.out.println("Outer" +i);
            orderedInsert(array, array[i], i);
        }

        // Print the updated array
        for (int value : array) {
            System.out.print(value + " ");
        }
    }

    public static void orderedInsert(int[] array, int value, int position) {
        // Move elements over to the right
        while (position > 0 && array[position-1] > value) {
            System.out.println("Inner"+position);
            array[position] = array[position - 1];
            position--;
        }

        // Insert the new value
        array[position] = value;
    }
}
