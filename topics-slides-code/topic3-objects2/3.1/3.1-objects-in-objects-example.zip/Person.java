public class Person {
	private String name;
	private int age;
	private Person spouse;
	private PersonList children;
	private PersonList partners;
	private PersonList parents;

	public Person() {
		this.name = "Newborn";
		this.age = 0;
		this.spouse = null; // non-existant
		this.children = new PersonList();
	}

	public Person(String name) {
		this.name = name;
		this.age = 0;
		this.spouse = null;
		this.children = new PersonList();
	}

	public Person (String name, int age) {
		this.name = name;
		this.age = age;
		this.spouse = null; // non-existant
		this.children = new PersonList();
	}

	public Person(String name, int age, Person otherHalf) {
		this.name = name;
		this.age = age;
		this.children = new PersonList();
		marries(otherHalf);
	}

	public void marries(Person p) {
		if(!this.isMarried() && !p.isMarried()) {
			this.spouse = p;
			p.spouse = this;
		}
		else {
			System.out.println("Cannot reassign spouse, value already present");
		}
	}

	public void divorce() {
		if(isMarried()) { // i do currently have a spouse
			this.spouse.spouse = null; // null.spouse = null
			this.spouse = null;
		}
	}

	public boolean isMarried() {
		return this.spouse != null; // if not null, then true, married
	}

	public void setName(String name) {
		this.name = name;
	}
	// birthing children
	public void birthChild(String name) {
		children.addPerson(new Person(name));
	}
	// adopting children
	public void adoptChild(Person child) {
		children.addPerson(child);
	}

	public void printChildren() {
		if(hasChildren()) {
			String result = name + "'s Children";
			result += children.toString();
			System.out.println(result);
		} else {
			System.out.println("Sorry, you do not have any children");
		}
	}

	public boolean hasChildren() {
		return children != null && !children.isEmpty();
	}

	public String toString() {
		String result = "Name: " + name + " Age: " + age;
		if(spouse != null) {
			result += "\nSpouse:\n\t" + "Name: " + spouse.name + " Age: " + spouse.age;
		}
		if(hasChildren()) {
			result += "\nChildren:";
			result += this.children.toString();
		}
		return result;
	}
}