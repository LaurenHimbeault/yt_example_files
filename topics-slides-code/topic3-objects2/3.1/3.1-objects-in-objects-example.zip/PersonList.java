public class PersonList {
	private static final int MAX_CHILDREN = 50;
	private Person[] children;
	private int currNumChildren;

	public PersonList() {
		this.children = new Person[MAX_CHILDREN];
		this.currNumChildren = 0;	
	}

	public void addPerson(Person child) {
		if(currNumChildren < children.length) {
			children[currNumChildren] = child;
			currNumChildren++;
		}
	}

	public boolean isEmpty() {
		return currNumChildren == 0;
	}

	public String toString() {	
		String result = "";
		for(int child = 0; child < currNumChildren; child++) {
			result += "\n\t" + children[child].toString();
		}
		return result;
	}
}
