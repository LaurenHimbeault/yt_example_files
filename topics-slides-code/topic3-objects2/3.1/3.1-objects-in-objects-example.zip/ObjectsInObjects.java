public class ObjectsInObjects {
	public static void main(String[] args) {
		Person saheel = new Person ("Saheel", 28);
		Person alison = new Person();
		Person jamal = new Person("Jamal", 29, saheel);
		alison.setName("Alison");
		System.out.println(jamal);
		System.out.println(saheel);
		System.out.println(alison);
		jamal.birthChild("Hassan");
		jamal.adoptChild(alison);
		jamal.printChildren();


		System.out.println(jamal);
		System.out.println(alison);
		alison.printChildren();
	}
}