
import java.util.ArrayList;
public class ArrayListExample {
	public static void main(String[] args) {
		
		MyArrayList a1 = new MyArrayList();
		a1.add("String1");
		a1.add("Another String");
		Object returned = a1.set(0, "set front");
		System.out.println("Old: " + returned);
		System.out.println(a1);

		ArrayList<String> a2 = new ArrayList<String> ();
		a2.add("String2");
		a2.add("Hippo");
		a2.add(0, "front add");
		String s = a2.set(0, "set front");
		System.out.println("Old: " + s);
		System.out.println(a2);

		String rem = a2.remove(0);
		boolean success = a2.remove("Hippo");
		System.out.println("Success?" + success);
		success = a2.remove("osdeuvbcas;idubfrv");
		System.out.println("Success?" + success);
		System.out.println(a2);


		System.out.println("EOP");		
	}	
}