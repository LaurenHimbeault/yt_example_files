public class MyArrayList {
    final static int INITIAL_SIZE = 10;

    private int size;
    private int[] values;

    public MyArrayList() {
        size = 0;
        values = new int[INITIAL_SIZE];
    }

    private void resize() {
        int[] newVals = new int[values.length * 2];
        for (int i = 0; i < size; i++) {
            newVals[i] = values[i];
        }
        values = newVals;
    }

    public void add(int newVal) {
        if (size == values.length) {
            resize();
        }
        values[size++] = newVal;
    }

    public void add(int index, int newVal) {
        if (size == values.length)
            resize();

        for (int i = size; i >= index; i--) {
            values[i] = values[i - 1];
        }

        values[index] = newVal;
    }

    public int get(int index) {
        // if (index < 0 || index > size)
        // throw IndexOutOfBoundsException("Out of bounds!");

        return values[index];
    }

    public int remove(int index) {
        int val = values[index];

        for (int i = index; i < size - 1; i++) {
            values[i] = values[i + 1];
        }
        size--;

        return val;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}