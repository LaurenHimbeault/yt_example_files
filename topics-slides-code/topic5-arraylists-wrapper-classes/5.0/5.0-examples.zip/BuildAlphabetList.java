import java.util.ArrayList;
import java.util.Scanner;

public class BuildAlphabetList {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		ArrayList<String> alpha = new ArrayList<String>();
		System.out.println("Enter a word or type Q to exit");
		String line = sc.nextLine();
		while(!line.equalsIgnoreCase("Q")) {
			// add to list
			orderedInsert(alpha, line);
			// print list
			System.out.println(alpha);
			// ask again
			System.out.println("Enter a word or type Q to exit");
			line = sc.nextLine();
		}
		// add a call to removeDuplicates(alpha) and then print alpha
		System.out.println("EOP");
	}

	public static void orderedInsert(ArrayList<String> alpha, String line) {
		int index = 0;

		while(index < alpha.size() && alpha.get(index).compareTo(line) < 0) {
			index++;
		}
		alpha.add(index, line);
	}
}