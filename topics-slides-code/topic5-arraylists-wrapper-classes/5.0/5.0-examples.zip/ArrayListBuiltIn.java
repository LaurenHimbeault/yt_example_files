import java.util.ArrayList;

public class ArrayListBuiltIn {
	public static void main(String[] args) {
		ArrayList<String> arrList = new ArrayList<String>();

		arrList.add("Dog");
		arrList.add("Cat");
		arrList.add("Lemur");
		arrList.add("Zebra");
		arrList.add("Gecko");
		arrList.add(0, "Fish");
		arrList.set(1, "Pig");

		arrList.remove(arrList.indexOf("Lemur") + 1);
		System.out.println(arrList); // What is our final al here?

		System.out.println(arrList);
		System.out.println("Size: " + arrList.size());

		arrList.remove(4);
		System.out.println(arrList);
		System.out.println("Size: " + arrList.size());

		System.out.println("Contains Pig? " + arrList.contains("Pig"));
		System.out.println("Contains Aardvark? " + arrList.contains("Aardvark"));
		System.out.println("IndexOf Pig? " + arrList.indexOf("Pig"));

	}
}