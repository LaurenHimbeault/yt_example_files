public class Person {
    public String name;
    public int age;

    public Person() {
        name = "I DONT HAVE A NAME YET";
        age = 0;
    }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void haveBirthday() {
        age++; // age = age + 1;
    }

    public void newBabyName(String name) {
        this.name = name;
    }

    public String toString() {
        return this.name + " is " + this.age + " years old";
    }
}
