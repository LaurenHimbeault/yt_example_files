public class MyProgram {
    public static void main(String[] args) {
        Person instructor = new Person("Lauren", 30);
        // instructor.name = null instructor.age = 0 (garbage)

        Person kid1 = new Person("Evan", 5);
        /* 
        if(instructor.age >= kid1.age) {
            System.out.println("The instructor is older than a child.");
        }

        System.out.println(kid1.name + " is " + kid1.age + " years old");
        kid1.haveBirthday();
        System.out.println(kid1.name + " is " + kid1.age + " years old");

        System.out.println(kid2.name + " is " + kid2.age + " years old");
        System.out.println(instructor.name + " is " + instructor.age + " years old");

        String s1 = "hello";
        */
        Person kid2 = new Person();
        System.out.println(kid2);
        kid2.newBabyName("Alison");
        kid2.age = 2;
        System.out.println(kid1);
        System.out.println(kid2);
        
        System.out.println(instructor);

    }


}