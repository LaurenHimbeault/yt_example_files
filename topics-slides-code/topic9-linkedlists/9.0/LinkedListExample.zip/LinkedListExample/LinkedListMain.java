public class LinkedListMain {
    public static void main(String[] args) {
        LinkedList ll = new LinkedList();
        System.out.println(ll); // prints null 
        ll.add(3);
        System.out.println(ll); // prints 3 
        ll.add(5);
        System.out.println(ll); // print 5 (even though 3 is still in there)
    }
}