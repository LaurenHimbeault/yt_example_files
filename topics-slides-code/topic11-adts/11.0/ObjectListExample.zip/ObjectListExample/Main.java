import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        final int MAX_RANDOM = 200;
        OrderedList ol;
        ol = new OrderedListArrayList();
        ArrayList<Integer> naturalGeneratedOrder = new ArrayList<Integer>();
        for(int i = 0; i < 20; i++) {
            int rand = (int)(Math.random() * MAX_RANDOM)+1;
            naturalGeneratedOrder.add(rand);
            ol.insert(rand);
        }
        System.out.println("Ordered Data\n");
        ol.printList();

        System.out.println("\nOriginal Natural Order");
        int spacer = 0;
        for(Object o : naturalGeneratedOrder) {
            System.out.print("\t" + o);
            spacer++;
            if(spacer == 4) {
                spacer = 0;
                System.out.println();
            }
        }

    }
}
