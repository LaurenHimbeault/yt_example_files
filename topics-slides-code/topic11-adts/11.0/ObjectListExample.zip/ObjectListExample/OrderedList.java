public interface OrderedList {
    Object get(int index); // return null if invalid index
    Object remove(int index); // return null if not exists
    boolean remove(Comparable o); // return true if removed or false if not exists
    int size();
    boolean contains(Comparable o); // return true if found and false otherwise
    int indexOf(Comparable o); // return object index if exists, -1 otherwise
    void insert(Comparable o); // insert the object into correct sorted Order
    void printList();
}
