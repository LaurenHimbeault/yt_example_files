import java.util.ArrayList;

public class OrderedListArrayList implements OrderedList{
    private ArrayList<Comparable> al;

    public OrderedListArrayList() {
        al = new ArrayList<Comparable>();
    }

    @Override
    public Object get(int index) {
        return al.get(index);
    }

    @Override
    public Object remove(int index) {
        return al.remove(index);
    }

    @Override
    public boolean remove(Comparable o) {
        return al.remove(o);
    }

    @Override
    public int size() {
        return al.size();
    }

    @Override
    public boolean contains(Comparable o) {
        return al.contains(o);
    }

    @Override
    public int indexOf(Comparable o) {
        return al.indexOf(o);
    }

    @Override
    public void insert(Comparable o) {
        int index = 0;
        while(index < al.size() && al.get(index).compareTo(o) < 0) {
            index++;
        }
        if(index == al.size()) {
            al.add(o);
        } else {
            al.add(index, o);
        }
        // ordered insert
    }

    @Override
    public void printList() {
        int spacer = 0;
        for(Comparable o : al) {
            System.out.print("\t"+o);
            spacer++;
            if(spacer == 4) {
                spacer = 0;
                System.out.println();
            }
        }
    }
}
