
public class Main {
    public static void main(String[] args) {
        /* Check LinkedList Class Works before continuing 
        LinkedList ll = new LinkedList();
        ll.addToFront(1);
        System.out.println(ll.getData(0));
        ll.remove(0);
        System.out.println(ll.isEmpty());
        
        Basic Stack Implementation Tests
        IStack stack = new StackLinkedList();
        stack.push(1);
        System.out.println(stack.peek());
        stack.pop();
        System.out.println(stack.isEmpty());
        */
        IStack stack2 = new StackLinkedList();

        // create a sequential stack
        for(int i = 0; i < 100; i++) {
            stack2.push(i);
        }
        // pop everything off and read the contents as they go
        int count = 0;
        while(!stack2.isEmpty()) {
            System.out.printf("%5d", stack2.pop());
            count++;
            if(count % 10 == 0) {
                System.out.println();
            }
        }
    }
}
