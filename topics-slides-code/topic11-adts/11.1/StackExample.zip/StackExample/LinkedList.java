public class LinkedList {
    private Node top;
    private int size;

    public LinkedList() {
        top = null;
        size = 0;
    }

    public void addToFront(int val) {
        top = new Node(val, top);
        size++;
    }

    public void addByIndex(int index, int val) {
        if(index >= 0 && index < size) {
            Node curr = top;
            Node prev = null;
            int i = 0;
            while (i < index) {
                prev = curr;
                curr = curr.next;
                i++;
            }
            if(index == 0 ){
                addToFront(val);
            }
            else {
                prev.next = new Node(val, curr);
            }
            size++;
        } else {
            System.out.println("Index does not exist");
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void remove(int index) {
        if(index >= 0 && index < size) {
            Node curr = top;
            Node prev = null;
            int i = 0;
            while (i < index) {
                prev = curr;
                curr = curr.next;
                i++;
            }
            if(index == 0 ){
                top = top.next;
            }
            else {
                prev.next = curr.next;
            }
            size--;
        } else {
            System.out.println("Index does not exist");
        }
    }

    public int getData(int index) {
        int dataVal = Integer.MIN_VALUE;
        if(index >= 0 && index < size) {
            Node curr = top;
            int i = 0;
            while (i != index) {
                curr = curr.next;
                i++;
            }
            dataVal = curr.data;
        } else {
            System.out.println("Invalid Index: Integer.MIN_VALUE is returned");
        }
        return dataVal;
    }

    class Node {
        int data;
        Node next;

        public Node(int data, Node next) {
            this.data = data;
            this.next = next;
        }
    }
}