public class StackLinkedList implements IStack {
    private LinkedList list;

    public StackLinkedList() {
        list = new LinkedList();
    }

    public void push(int val) {
        list.addToFront(val);
    }

    
    public int pop() {
        int popped = list.getData(0);
        list.remove(0);
        return popped;
    }

    
    public int peek() {
        return list.getData(0);
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }
    
}
