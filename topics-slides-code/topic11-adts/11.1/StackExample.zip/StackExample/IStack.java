public interface IStack {
    void push(int val); // adds to top of stack
    int pop(); // remove and return the top element
    int peek(); // looks at the top element
    boolean isEmpty();
}
