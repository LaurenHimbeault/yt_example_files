public class QueueLinkedList implements IQueue{
    private LinkedList list;

    public QueueLinkedList() {
        list = new LinkedList();
    }

    public void enqueue(int val) {
        list.addToEnd(val);
    }

    public int dequeue() {
        int dequeued = list.getData(0);
        list.remove(0);
        return dequeued;
    }

    public int peek() {
        return list.getData(0);
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }
}
