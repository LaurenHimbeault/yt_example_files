public class LinkedList {
    private Node top;
    private Node tail;
    private int size;

    public LinkedList() {
        top = null;
        tail = null;
        size = 0;
    }

    public void addToFront(int val) {
        Node n = new Node(val, null);
        if(top == null) {
            top = n;
            tail = n;
        } else {
            n.next = top;
            top = n;
        }
        size++;
    }

    public void addToEnd(int val) {
        Node curr = top;
        if(curr == null) {
            addToFront(val);
            size++;
        }
        else {
            tail.next = new Node(val, null);
            tail = tail.next;
            size++;
        }
    }

    public void addByIndex(int index, int val) {
        if(index >= 0 && index <= size) {
            Node curr = top;
            Node prev = null;
            int i = 0;
            while (i < index) {
                prev = curr;
                curr = curr.next;
                i++;
            }
            if(index == 0 ){
                addToFront(val);
            }
            else {
                prev.next = new Node(val, curr);
                if(curr == null) { // prev was old tail
                    tail = prev.next;
                }
            }
            size++;
        } else {
            System.out.println("Index does not exist");
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    public int size() {
        return size; // "next open spot"
    }

    public void remove(int index) {
        if(index >= 0 && index < size) {
            Node curr = top;
            Node prev = null;
            int i = 0;
            while (i < index) {
                prev = curr;
                curr = curr.next;
                i++;
            }
            if(index == 0 ){
                top = top.next;
            }
            else {
                prev.next = curr.next;
                if(curr.next == null) {
                    tail = prev;
                }
            }
            size--;
        } else {
            System.out.println("Index does not exist");
        }
    }

    public int getData(int index) {
        int dataVal = Integer.MIN_VALUE;
        if(index >= 0 && index <= size) {
            Node curr = top;
            int i = 0;
            while (i != index) {
                curr = curr.next;
                i++;
            }
            dataVal = curr.data;
        } else {
            System.out.println("Invalid Index: Integer.MIN_VALUE is returned");
        }
        return dataVal;
    }

    class Node {
        int data;
        Node next;

        public Node(int data, Node next) {
            this.data = data;
            this.next = next;
        }
    }
}