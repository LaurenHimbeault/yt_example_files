public interface IQueue {
    void enqueue(int val); // put val at end of queue
    int dequeue(); // remove and return the first element in the queue
    int peek(); // look at the queue and see who is up "next"
    boolean isEmpty();
}
