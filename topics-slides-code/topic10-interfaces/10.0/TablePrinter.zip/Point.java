public class Point implements ITablePrintable {
    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void printHeader() {
        System.out.println("X/Y PAIRING");
    }

    @Override
    public void printData() {
        System.out.printf("(%.2f,%.2f)\n", x, y);
    }

    
}
