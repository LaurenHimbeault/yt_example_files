import java.util.ArrayList;

public class PrintingExample {
    public static void main(String[] args) {

        ArrayList<Point> points = new ArrayList<Point>();
        for(int i = 0; i < 10; i++) {
            points.add(new Point(Math.random()*i, Math.random()*i));
        }
        for(Point p : points) {
            p.printData();
        }
    }
}
