public class Person implements ITablePrintable {
    private String name;
    private int age;
    private long studentNumber;
    // name
    // age
    // student number

    // constructor
    public Person(String name, int age, long studentNumber) {
        this.name = name;
        this.age = age;
        this.studentNumber = studentNumber;
    }

    public String getStudentInfo() {
        return name + " (" +studentNumber + ")";
    }

    public boolean equals(Object p) {
        return this.studentNumber == ((Person)p).studentNumber;
    }
    
    // toString
    public String toString() {
        String result = "Name: " + name;
        result += "\n\tAge: " + age;
        result += "\n\tStudent #: " + studentNumber;
        return result;
    }

    @Override
    public void printHeader() {
       System.out.println("Student Information");
    }

    @Override
    public void printData() {
        System.out.println("\t" + name + "\t(" + studentNumber + ")");
    }

}
