import java.util.ArrayList;

public class Course implements IEnrollable, ITablePrintable {
    private ArrayList<Person> classList;
    private String name;
    private int courseCode;
    private int capacity;
    
    public Course(String name, int courseCode, int capacity) {
        this.classList = new ArrayList<Person>();
        this.name = name;
        this.courseCode = courseCode;
        this.capacity = capacity;
    }

    public int getCourseCode() {
        return courseCode;
    }

    public String toString() {
        return courseCode + " - " + name;
    }

    @Override
    public void addStudent(Person p) {
        if(!classList.contains(p)) {
            classList.add(p);
        }
    }

    @Override
    public void removeStudent(Person p) {
        if(!classList.contains(p)) { 
            System.out.println("Person not in list");
        } else {
            classList.remove(p);
        }
    }

    @Override
    public String getName() {
        return courseCode + " - " + name;
    }

    public int getNumEnrolled() {
        return classList.size();
    }

    public boolean isFull() {
        return getNumEnrolled() == capacity;
    }

    @Override
    public void printHeader() {
        System.out.println("Course: " + getName());
    }

    @Override
    public void printData() {
        System.out.println("Students Registered: ");
        if(classList.size() == 0) System.out.println("\tClass List is Empty");
        for(Person student : classList) {
            student.printData();
        }
    }
}
