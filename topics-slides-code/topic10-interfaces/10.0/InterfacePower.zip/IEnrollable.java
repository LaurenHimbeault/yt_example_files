// add student to the course
// remove student from the course
// get the name of the class
public interface IEnrollable {
    // adds student if they are not already in class
    void addStudent(Person p);

    // removes student or prints "does not exist" message
    void removeStudent(Person p);

    // returns the string of the enrollable data type
    String getName();

    int getNumEnrolled();

    boolean isFull();
}