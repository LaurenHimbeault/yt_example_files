public interface ITablePrintable {
    void printHeader();
    void printData();
}
