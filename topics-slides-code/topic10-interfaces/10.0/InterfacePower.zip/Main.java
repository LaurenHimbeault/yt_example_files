import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        /* INITIAL EXAMPLE
        Person p = new Person("Jasmine", 20, 1234567);
        // System.out.println(p);
        Course c = new Course("Intro Programming 2", 1020, 1);
        c.addStudent(p);
        // System.out.println(c.isFull());

        c.printHeader();
        c.printData();

        StudentGroup wics = new StudentGroup("WICS");
        wics.addStudent(p);
        //  System.out.println(wics.isFull());
        wics.printHeader();
        wics.printData();
        */
        ArrayList<ITablePrintable> canJoins = new ArrayList<ITablePrintable>();
        canJoins.add(new Course("Intro Programming 2", 1020, 1));
        canJoins.add(new StudentGroup("WICS"));
        canJoins.add(new StudentGroup(".devClub"));
        canJoins.add(new StudentGroup("CSSA"));
        canJoins.add(new Course("Intro Programming 1", 1010, 1));

        for(ITablePrintable ie : canJoins) {
           printAllData(ie);
        }

        //ITablePrintable course1 = new Course("CS 2", 1020, 2);
        //System.out.println(course1.getCourseCode());
        StudentGroup wics = new StudentGroup("WICS");
        printAllData(wics);
    }

    public static void printAllData(ITablePrintable itp) {
        itp.printHeader();
        itp.printData();
    }
}
