import java.util.ArrayList;

public class StudentGroup implements IEnrollable, ITablePrintable {
    private String name;
    private ArrayList<Person> members;

    public StudentGroup(String name) {
        this.name = name;
        this.members = new ArrayList<Person>();
    }

    @Override
    public void addStudent(Person p) {
        if(members.contains(p)) {
            System.out.println("Student is already a member");
        } else {
            members.add(p);
        }
    }

    @Override
    public void removeStudent(Person p) {
        if(!members.contains(p)) {
            System.out.println("Student not a member");
        } else {
            members.remove(p);
        }
    }

    @Override
    public String getName() {
        return name;
    }

    public int getNumEnrolled() {
        return members.size();
    }

    public boolean isFull() {
        return false;
    }

    @Override
    public void printHeader() {
        System.out.println("Student Group Name: " + getName());
    }

    @Override
    public void printData() {
        System.out.println("Members");
        if(members.size() == 0) System.out.println("\tNo Members Currently");
        for(Person p : members) {
            p.printData();
        }   
    }
}
