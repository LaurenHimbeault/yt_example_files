import java.util.Scanner;

public class ExceptionExample {
	public static void main(String[] args) {
		double math = 0; // 5/0;
		System.out.println(math);

		// snacks(); // example of stackoverflowError
		try {
			int num = getUserInputNumber();
			System.out.println("You entered a " + num);
		} catch(NumberFormatException nfe) {
			System.out.println("That wasn't a valid number");
			System.out.println("Exception message:\n" + nfe.getMessage());
		}
		System.out.println("End of Processing");


	}

	public static void snacks() { snacks(); }

	public static int getUserInputNumber() throws NumberFormatException {
		Scanner sc = new Scanner(System.in);
		int result = -1;
		
		System.out.println("Enter a non-negative number");
		String strIn = sc.nextLine();		
		result = Integer.parseInt(strIn);
		if(result < 0) {
			throw new NumberFormatException("THAT WAS NEGATIVE");
		}
	
		return result;
	}
}





