

public class Main {
    public static void main(String[] args) {
        ListYearlyData allData = new ListYearlyData();
        System.out.println(allData);
        System.out.println("End of Processing");
    }
}