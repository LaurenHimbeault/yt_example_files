public class CharMatrixMain {
    public static void main(String[] args) {
        final int NUM_ROWS = 5;
        final int NUM_COLS = 5;
        final char SYMBOL = '\u263A';
        CharMatrix cm = new CharMatrix(NUM_ROWS, NUM_COLS, SYMBOL);
        System.out.println("New Matrix Created");
        System.out.println(cm);

        System.out.println("Fill All Spots");
        cm.fillAll();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Top Half");
        cm.fillTopHalf();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Front Diagonal");
        cm.fillFrontDiagonal();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Top Diagonal");
        cm.fillTopDiagonal();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Below Diagonal");
        cm.fillBelowDiagonal();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Even Rows");
        cm.fillEvenRows();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Even Cols");
        cm.fillEvenCols();
        System.out.println(cm);
        cm.empty();

        System.out.println("Fill Checkerboard");
        cm.fillCheckerBoard();
        System.out.println(cm);
        cm.empty();

        System.out.println("End of Processing");
    }
}
