public class CharMatrix {
    private char[][] matrix;
    private int rows;
    private int cols;
    private char symbol;
    private boolean isEmpty;

    public CharMatrix(int rows, int cols, char symbol) {
        // assuming the rows cols are non zero positive values
        this.rows = rows;
        this.cols = cols;
        this.symbol = symbol;
        matrix = new char[rows][cols];
        isEmpty = true;
        initialFill();
    }

    private void initialFill() {
        for(char[] row : matrix) {
            for(int i=0; i < row.length; i++) {
                row[i] = '-';
            }
        }
    }

    // fill all cells with the specified symbol
    public void fillAll() {
        isEmpty = false;
        for(char[] row : matrix) {
            for(int i=0; i < row.length; i++) {
                row[i] = symbol;
            }
        }
    }

    // empty out all cells
    public void empty() {
        isEmpty = true;
        matrix = new char[rows][cols];
        initialFill();
    }

    public void fillTopHalf() {
        // no longer empty
        isEmpty = false;
        // fill the top half of the matrix with the given symbol
        // figure out where rows are the top half?
        int halfRows = rows/2;
        // for each row in the top half
        for(int row = 0; row < halfRows; row++) {
            // for each cell in the current row
            for(int col = 0; col < cols; col++) {
                // set that cell value to the symbol
                matrix[row][col] = symbol;
            }
        }
        
    }

    // fill the front diagonal
    // does not require a square matrix
    // starts at 00 and creates diagonal as far as it can
    public void fillFrontDiagonal() {
        isEmpty = false;
        int row = 0;
        while(row < rows && row < cols) {
            matrix[row][row] = symbol;  
            row++;
        }
    }

    public void fillTopDiagonal() {
        isEmpty = false;
        // for every row
        for(int row = 0; row < rows; row++) {
            // starting at the front diagonal point (row==co)
            for(int col = row; col < cols; col++) {
                // fill symbols to end of row
                matrix[row][col] = symbol;
            }
        }
    }

    public void fillEvenRows() {
        isEmpty = false;
        for(int row = 0; row < rows; row++) {
            if(row % 2 == 0) {
                for(int col = 0; col <  cols; col++) {
                    matrix[row][col] = symbol;
                }
            }
        }
    }

    public void fillEvenCols() {
        // don't forget to set isEmpty = false!
        System.out.println("fillBelowDiagonal not yet implemented");
    }

    public void fillBelowDiagonal() {
        // don't forget to set isEmpty = false!
        System.out.println("fillBelowDiagonal not yet implemented");
    }


    public void fillCheckerBoard() {
        // first row we fill even col cells
        // second row we fill odd col cells
        // third row we fill even col cell
        isEmpty = false;
        fillRowRec(0, 0);
    }
    
    private void fillRowRec(int currRow, int cellIndex) {
        if(currRow < rows) {
            fillColRec(currRow, cellIndex);
            fillRowRec(currRow+1, (cellIndex+1)%2);
        }
    }

    private void fillColRec(int currRow, int cellIndex) {
        if(cellIndex < cols) { // recursive case
            matrix[currRow][cellIndex] = symbol;
            fillColRec(currRow, cellIndex+2);
        }
        // else do nothing, no base case needed
    }

    public String toString() {
        String result = "";
        if(isEmpty) { result = "Your CharMatrix is Empty"; } 
        else {
            for(char[] row : matrix) {
                for(char el : row) {
                    result += el + "  ";
                }
                result += "\n";
            }
        }
        return result;
    }
}
