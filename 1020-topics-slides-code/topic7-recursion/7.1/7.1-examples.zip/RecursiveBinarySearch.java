public class RecursiveBinarySearch {
		public static void main(String[] args) {
		int[] arr = {-9,2,3,4,5,6,9,11};
		int target = 9;
		int foundIndex = binary(arr, target);
		System.out.println(foundIndex);
	}
	public static int binary(int[] arr, int target) {
		return binaryRec(0, arr.length, target, arr);
	}
	private static int binaryRec(int lo, int hi, int target, int[] arr) {
		int mid = (int)Math.floor((hi + lo)/2);
		if(hi < lo) { return -1; }
		else if(arr[mid] == target) { return mid; }
		else if(arr[mid] < target) { while
			return binaryRec(mid+1, hi, target, arr);
		}
		else { // arr[mid] > target
			return binaryRec(lo, mid, target, arr);
		}
	}
}




