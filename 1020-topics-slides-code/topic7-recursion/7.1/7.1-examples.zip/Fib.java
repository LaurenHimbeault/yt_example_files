public class Fib {

    public static void main(String[] args) {
        int n = 30; // Example number for Fibonacci calculation

        // Measure and print iterative Fibonacci calculation
        long startTimeIterative = System.nanoTime();
        int fibIterative = fibonacciIterative(n);
        long endTimeIterative = System.nanoTime();
        long durationIterative = (endTimeIterative - startTimeIterative) / 1000000; // Convert to milliseconds
        System.out.println("Iterative Fibonacci of " + n + ": " + fibIterative);
        System.out.println("Iterative calculation took: " + durationIterative + " milliseconds");

        // Measure and print recursive Fibonacci calculation
        long startTimeRecursive = System.nanoTime();
        int fibRecursive = fibonacciRecursive(n);
        long endTimeRecursive = System.nanoTime();
        long durationRecursive = (endTimeRecursive - startTimeRecursive) / 1000000; // Convert to milliseconds
        System.out.println("Recursive Fibonacci of " + n + ": " + fibRecursive);
        System.out.println("Recursive calculation took: " + durationRecursive + " milliseconds");
    }

    // Iterative version of Fibonacci calculation
    public static int fibonacciIterative(int n) {
        if (n <= 1) {
            return n;
        }
        int fib = 1;
        int prevFib = 1;

        for (int i = 2; i < n; i++) {
            int temp = fib;
            fib += prevFib;
            prevFib = temp;
        }

        return fib;
    }

    // Recursive version of Fibonacci calculation
    public static int fibonacciRecursive(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }
}
