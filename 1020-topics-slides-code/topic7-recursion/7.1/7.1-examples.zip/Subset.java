import java.util.ArrayList;
import java.util.List;

public class Subset {

    public static void main(String[] args) {
        List<Integer> inputList = new ArrayList<>();
        int n = 5; // Size of the ArrayList
        int k = 3; // Size of the subset
        // Fill the list with example elements
        for (int i = 1; i <= n; i++) {
            inputList.add(i);
        }
        
        findSubsetsOfSizeK(inputList, new ArrayList<>(), 0, k);
    }

    public static void findSubsetsOfSizeK(List<Integer> originalList, List<Integer> currentSubset, int start, int k) {
        // If the current subset reaches the target size, print it
        if (currentSubset.size() == k) {
            System.out.println(currentSubset);
            return;
        }
        
        for (int i = start; i < originalList.size(); i++) {
            // Include the current element and move to the next
            currentSubset.add(originalList.get(i));
            findSubsetsOfSizeK(originalList, currentSubset, i + 1, k);
            // Exclude the current element (backtrack) and try the next
            currentSubset.remove(currentSubset.size() - 1);
        }
    }
}

