import java.util.ArrayList;
import java.util.List;

public class Permutations {

    public static void main(String[] args) {
        // Initialize an ArrayList with some integers
        List<Integer> nums = new ArrayList<>();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        
        // Generate all permutations of the ArrayList
        List<List<Integer>> result = permute(nums);
        
        // Print the list of all permutations
        System.out.println(result);
    }

    // Function to initiate the permutation process
    public static List<List<Integer>> permute(List<Integer> nums) {
        // A list to store all the permutations
        List<List<Integer>> list = new ArrayList<>();
        
        // Start the recursive backtracking process with an empty temporary list for the current permutation
        backtrack(list, new ArrayList<>(), nums);
        
        // Return the list of permutations
        return list;
    }

    // The recursive function to generate permutations
    private static void backtrack(List<List<Integer>> list, List<Integer> tempList, List<Integer> nums) {
        // Base case: if the size of the tempList is equal to the size of nums, we found a permutation
        if (tempList.size() == nums.size()) {
            // Add a new permutation to the list of permutations
            list.add(new ArrayList<>(tempList));
        } else {
            // Iterate through all elements in nums to generate permutations
            for (int i = 0; i < nums.size(); i++) {
                // Skip the current element if it's already in tempList (to avoid duplicate permutations)
                if (tempList.contains(nums.get(i))) continue;
                
                // Add the current element to the tempList
                tempList.add(nums.get(i));
                
                // Continue building the permutation with the next elements
                backtrack(list, tempList, nums);
                
                // Backtrack: remove the last element added to tempList to try the next element
                tempList.remove(tempList.size() - 1);
            }
        }
    }
}
