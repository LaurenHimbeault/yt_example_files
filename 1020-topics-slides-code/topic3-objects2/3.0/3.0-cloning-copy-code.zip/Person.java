public class Person {
	private String name;
	private int age;

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public Person(Person p) {
		this.name = p.name;
		this.age = p.age;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Person clone() {
		Person newPerson = new Person(this.name, this.age);
		return newPerson;
	}

	public String toString() {
		return "Name: " + name  + " Age: " + age;
	}
}