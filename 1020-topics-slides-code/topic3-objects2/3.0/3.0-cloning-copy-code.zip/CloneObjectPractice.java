public class CloneObjectPractice {
	public static void main(String[] args) {

		//showShallowVsDeepObjects();
		//stringsAlwaysDeep();
		deepCopyWithConstructor();
	}

	public static void showShallowVsDeepObjects() {
		Person anik = new Person("Anik", 25);
		Person anik2 = anik; // just moving the memory address
		System.out.println("Anik object " + anik);
		System.out.println("Anik2 object " + anik2);
		anik.setName("ChangedAnik");
		System.out.println("Anik object " + anik);
		System.out.println("Anik2 object " + anik2);

		anik2 = anik.clone(); // a new person in a new memory address separate of the old one
		anik.setName("Anik");

		System.out.println("After clone: Anik object " + anik);
		System.out.println("After clone:: Anik2 object " + anik2);
	}

	public static void stringsAlwaysDeep() {
		// Not a problem with strings
		String hello = "hello";
		String world = hello;
		System.out.println("Hello variable: " + hello);
		System.out.println("World variable: " + world);
		hello = "snacks";
		System.out.println("Change Hello");
		System.out.println("Hello variable: " + hello);
		System.out.println("World variable: " + world);
	}

	public static void deepCopyWithConstructor() {
		Person anik = new Person("Anik", 25);
		Person anik2 = new Person(anik);
		System.out.println(anik == anik2);
	}
}