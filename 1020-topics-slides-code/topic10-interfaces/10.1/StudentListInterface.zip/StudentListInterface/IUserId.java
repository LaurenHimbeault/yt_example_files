public interface IUserId {
    int getIDNumber();
}
