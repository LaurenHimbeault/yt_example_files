import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Advisor lauren = new Advisor("Lauren", 123456);
        UndergraduateStudent us = new UndergraduateStudent("Anmol", 123456789, 4.2);
        GraduateStudent gs = new GraduateStudent("Avril", 1, 4.1, lauren);
        System.out.println(lauren);
        us.printStudentInformation();
        gs.printStudentInformation();
        ArrayList<IUserId> systemPeople = new ArrayList<IUserId>();
        systemPeople.add(us);
        systemPeople.add(gs);
        systemPeople.add(lauren);
        System.out.println(systemPeople);
    }
}
