import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Advisor implements IUserId, Comparable<IUserId> {
    private String name;
    private int employeeNumber;
    private List students; // students under supervision

    public Advisor(String name, int employeeNumber) {
        this.name = name;
        this.employeeNumber = employeeNumber;
        this.students = new StudentList();
    }

    public void adviseNewStudent(IStudent student) {
        students.add(student);
    }

    public void studentGraduates(IStudent student) {
        // find student that is graduating
        // if undergrad student say congrats on bachelors degree
        // if ghraduate student say congrats on graduate degree
        // if student does not exist, say " you are not my student"
        System.out.println("NOT YET IMPLEMENTED");
    }

    public String toString() {
        return "Advisor's Name: " + name + " (" + employeeNumber+ ")";
    }

    @Override
    public int getIDNumber() {
        return employeeNumber;
    }

    @Override
    public int compareTo(IUserId o) {
        return this.getIDNumber() - o.getIDNumber();
    }
}
