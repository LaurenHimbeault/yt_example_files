public interface IStudent {
    double getGPA();
    void printStudentInformation();
}
