public class UndergraduateStudent implements IStudent, IUserId, Comparable<IUserId> {
    private String name;
    private int studentNumber;
    private double gpa;

    public UndergraduateStudent(String name, int studentNumber, double gpa) {
        this.name = name;
        this.studentNumber = studentNumber;
        this.gpa = gpa;
    }

    @Override
    public double getGPA() {
        return gpa;
    }

    @Override
    public void printStudentInformation() {
        System.out.println("Name: " + name + "("+studentNumber+"): Undergraduate");
    }

    @Override
    public int getIDNumber() {
        return studentNumber;
    }

    @Override
    public int compareTo(IUserId o) {
        return this.studentNumber - o.getIDNumber();
    }

    public String toString() {
        return "Name: " + name + "("+studentNumber+"): Undergraduate";
    }
}