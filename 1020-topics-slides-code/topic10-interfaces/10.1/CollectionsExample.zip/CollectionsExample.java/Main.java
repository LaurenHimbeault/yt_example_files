import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<Student>();
        students.add(new Student("Isham", 12345));
        students.add(new Student("Mia", 1111));
        students.add(new Student("Apoorva", 8734));


        ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(5);
        al.add(3);
        al.add(11);
        al.add(9);
        System.out.println("Before Sort");
        System.out.println(al);
        Collections.sort(al);
        System.out.println("After Sort");
        System.out.println(al);
 
        
        System.out.println("Before Sort");
        System.out.println(students);
        Collections.sort(students);
        System.out.println("After Sort");
        System.out.println(students);
    }
}
