public class Student implements Comparable<Student> {
    private String name;
    private int studentNumber;

    public Student(String n, int num) {
        name = n;
        studentNumber = num;
    }

    public String toString() {
        return "Name: " + name + " (" + studentNumber + ")";
    }

    @Override
    public int compareTo(Student o) {
        return this.studentNumber - o.studentNumber;
    }
}