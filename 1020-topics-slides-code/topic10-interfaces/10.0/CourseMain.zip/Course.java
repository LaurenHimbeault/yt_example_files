public class Course implements ITablePrintable {
    private String courseName;
    private String department;
    private String instructor;

    public Course(String x, String y, String z) {
        this.courseName = x;
        this.department = y;
        this.instructor = z;
    }

    @Override
    public void printHeader() {
        System.out.println("Faculty: " + department);
    }

    @Override
    public void printData() {
        System.out.printf("%s\t%s\n", courseName, instructor);
    }

    
}
