import java.util.ArrayList;

public class CourseMain {
    public static void main(String[] args) {

        ArrayList<Course> courses = new ArrayList<Course>();
        courses.add(new Course("CS 1", "CS", "Lauren"));
        courses.add(new Course("CS 2", "CS", "Zach"));
        courses.add(new Course("MATH 1", "MATH", "Athena"));
        courses.add(new Course("STATS 1", "STATS", "Rebecca"));
        for(Course p : courses) {
            p.printHeader();
            p.printData();
        }
    }
}
