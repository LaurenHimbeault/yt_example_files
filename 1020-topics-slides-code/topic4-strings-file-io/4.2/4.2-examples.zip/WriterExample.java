import java.io.*;

public class WriterExample {
	public static void main(String[] args) {
		try {
			
			PrintWriter pw = new PrintWriter(new File("write.txt"));
			pw.println("Hey using File objects now");
			pw.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			System.out.println("End of Processing");
		}
	}
}