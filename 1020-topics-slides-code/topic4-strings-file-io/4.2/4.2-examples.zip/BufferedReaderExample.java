import java.util.Scanner;
import java.io.*;

public class BufferedReaderExample {
	public static void main(String[] args) {
		try {
			File f = new File("numbers.txt");
			Scanner sc = new Scanner(f);

			while(sc.hasNextLine()) {
				String line = sc.nextLine();
				Scanner lineSc = new Scanner(line); // 4 5 6
				int sum = 0;
				while(lineSc.hasNextInt()) {
					sum += lineSc.nextInt();
				}
				System.out.println(line + " summed up is " + sum);
				line = br.readLine();
			}
			br.close();
			fr.close();
		} catch(IOException ioe) {
			System.out.println(ioe.getMessage());
		}
	}
}