import java.util.*;
import java.io.*;

public class ReadToObject {
	public static void main(String[] args) {
		final String INPUT_FILE_NAME = "person.txt";
		readFile(INPUT_FILE_NAME);
		System.out.println("End of Processing");
	}

	public static void readFile(String fileName) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("person.txt"));
			String line = br.readLine();
			while(line != null) {
				// constructor processes the file
				Person p = new Person(line);
				line = br.readLine();
			}
		}
	}
}