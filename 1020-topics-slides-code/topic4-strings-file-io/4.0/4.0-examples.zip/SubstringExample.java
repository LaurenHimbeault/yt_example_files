public class SubstringExample {
	public static void main(String[] args) {
		String s = "world";
		System.out.println(s);

		System.out.println(s.substring(1,2)); // "o"
		System.out.println(s.substring(1)); // "orld"

		// pull o out of string
		int pos = s.indexOf("o");
		if(pos >= 0) {
			System.out.println(s.substring(0,pos)+""+s.substring(pos+1)); //"wrld"
		}
		System.out.println(s.substring(0,s.length()-1));
		System.out.println(s.substring(1000, 10002));
	}
}