public class PalindromeExample {
	public static void main(String[] args) {
		String str = "nurses run"; // this is a palindrome
		boolean isPalindrome = checkPalindrome(str);
		System.out.println("Palindrome status of " + str + ": " + isPalindrome);
	}

	public static boolean checkPalindrome(String originalStr) {
		// palindrome is a string that readsthe same forwards and backward
		// ignoring case, spaces, and punctuation
		boolean isPalindrome = true;
		String s = originalStr.toUpperCase();
		//s = s.trim();
		s = s.replaceAll(" ", "");
		s = s.replace("!", "");
		s = s.replace("?", "");
		s = s.replace(",", "");
		s = s.replace(".", "");
		for(int i = 0; i < (int)(s.length()/2) && isPalindrome; i++) {
			char char1 = s.charAt(i);
			char char2 = s.charAt(s.length()-1-i);
			if(char1 != char2) { // ith from front and ith from back are not equal
				isPalindrome = false;
			}
		}
		return isPalindrome;

	}
}