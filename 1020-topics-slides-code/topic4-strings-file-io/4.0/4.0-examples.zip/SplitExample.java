public class SplitExample {
	public static void main(String[] args) {
		String s = "abcabcabcqrtbasabz";//c c cqrtbas z
		System.out.println(s);
		System.out.println();
		System.out.println();
		String[] tokens = s.split("ab");
		for(String token: tokens) {
			System.out.println(token + " ");
		}
	}
}