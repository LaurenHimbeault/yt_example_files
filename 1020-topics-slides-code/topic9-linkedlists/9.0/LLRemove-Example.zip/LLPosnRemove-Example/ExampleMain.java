public class ExampleMain {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
/*      list.addToPosn(7, 0);
        list.addToPosn(14, 0);
        list.addToPosn(22, 0);
        list.addToPosn(3, 0);
        System.out.println(list);
        list.remove(Integer.valueOf(-1)); //  Should output "Element did not exist"      
        list.remove(Integer.valueOf(3));
        System.out.println(list);
        list.remove(Integer.valueOf(14));
        System.out.println(list);
        list.remove(Integer.valueOf(7));
        System.out.println(list);
        System.out.println("Size: " + list.size());

        list.remove(0);
        System.out.println(list);
        System.out.println("Size: " + list.size());
*/
        list.remove(Integer.valueOf(100));
        System.out.println(list);


    }
}
