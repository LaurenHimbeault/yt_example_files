public class LinkedList {

    private Node top;
    private int numElements;

    public LinkedList() {
        this.top = null;
        numElements = 0;
    }

    public void addToPosn(Object obj, int index) {
        if(index < 0 || index > numElements) { throw new IndexOutOfBoundsException(index + " Cannot be Indexed"); }
        if(index == 0) { // adding to front
            top = new Node(obj, top); // make a new node pointing where top is and THEN set top to that node
            numElements++;
        }
        else { // index > 0
            Node prev = getByIndex(index - 1);
            Node curr = prev.next;
            Node newNode = new Node(obj, curr);
            prev.next = newNode;
            numElements++;
        }
    }

    public void remove(Object obj) {
        Node curr = top;
        Node prev = null;
        while(curr != null && !curr.data.equals(obj)) {
            prev = curr;
            curr = curr.next;
        }
        if(curr == null) {
            System.out.println("Element did not exist");
        }
        else {
            if(curr == top) { // remove the top element
                top = top.next; // move the trainyard supervisor over
            }
            else { // not removing the top, so some other one
                prev.next = curr.next;
            }
            numElements--;
        }
    }

    private Node getByIndex(int index) {
        Node curr = top;
        int currPosn = 0;
        while(curr != null && currPosn != index) {
            curr = curr.next;
            currPosn++;
        }       
        return curr;   
    }

    public void remove(int index) {
        if(index < 0 || index > numElements || numElements == 0) { throw new IndexOutOfBoundsException(index + " Cannot be Indexed"); }
        if(index == 0) { // removing from front
            top = top.next;            
            numElements--;
        }
        else { // index > 0
            Node prev = getByIndex(index - 1); //node before the one we want to delete
            Node curr = prev.next;
            prev.next = curr.next; // before we run this line prev.next is curr 
            numElements--;
        }
    }


    public int size() {
        return numElements;
    }

    public String toString() {
        Node curr = top;
        String result = "<<";
        while(curr != null) {
            result += " " + curr.data;
            curr = curr.next;
        }
        result += ">>";
        return result;
    }

    class Node {
        Object data;
        Node next;

        public Node(Object obj, Node n) {
            this.data = obj;
            this.next = n;
        }
    }
}