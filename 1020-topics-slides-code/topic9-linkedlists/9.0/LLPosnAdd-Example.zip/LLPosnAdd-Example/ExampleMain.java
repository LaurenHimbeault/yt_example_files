public class ExampleMain {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.addToPosn(2, 0); // check add to front works with no elements
        list.addToPosn(1, 0); // check add to front works with 1+ element
        list.addToPosn(0, 0); // check add to front works with 1+ element

        System.out.println(list);

        try { 
            list.addToPosn(5, -1); // this should throw the exception we wrote
        }
        catch(IndexOutOfBoundsException iobe) {
            iobe.printStackTrace();
            System.out.println("EXPECTED EXCEPTION THROWN HERE");
        }

        list.addToPosn(4, 1); // check add to middle
        System.out.println(list);
        list.addToPosn(5, 4); // posn 4 doesn't exist, it is the end of the list
        System.out.println(list);
        try {
            list.addToPosn(6, 100000); // this is WAYYYYY outside the available indices
        } catch (IndexOutOfBoundsException iobe) {
            iobe.printStackTrace();
            System.out.println("EXPECTED EXCEPTION");
        }
        System.out.println(list);
    }
}
