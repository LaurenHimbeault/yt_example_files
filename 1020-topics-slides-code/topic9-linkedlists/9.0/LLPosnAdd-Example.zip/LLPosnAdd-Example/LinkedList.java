public class LinkedList {

    private Node top;
    public LinkedList() {
        this.top = null;
    }

    public void addToPosn(Object obj, int index) {
        if(index < 0) { throw new IndexOutOfBoundsException("Negative Numbers Cannot be Indexed"); }
        if(index == 0) { // adding to front
            top = new Node(obj, top); // make a new node pointing where top is and THEN set top to that node
        }
        else { // index > 0
            Node curr = top;
            Node prev = null; // chillin with their drink
            int currPosn = 0;
            while(curr != null && currPosn != index) {
                prev = curr;
                curr = curr.next;
                currPosn++;
            }
            if (curr == null) { // must be at the end of the list 
                if(currPosn != index) { // index must be WAY bigger than the actual list
                    throw new IndexOutOfBoundsException(index + " is too big. There are only " + currPosn + " elements in the list");
                }
            }
            Node newNode = new Node(obj, curr);
            prev.next = newNode;
        }
    }

    public String toString() {
        Node curr = top;
        String result = "<<";
        while(curr != null) {
            result += " " + curr.data;
            curr = curr.next;
        }
        result += ">>";
        return result;
    }

    class Node {
        Object data;
        Node next;

        public Node(Object obj, Node n) {
            this.data = obj;
            this.next = n;
        }
    }
}