public class LinkedList {
    private Node top;

    public LinkedList() { this.top = null; }
    private boolean isEmpty() { return this.top == null; }

    public void orderedInsert(Object insert) {
        // we start at the front of our list
        Node prev = null;
        Node curr = top;
        Node toInsert = new Node(insert);
        // we compare elements until we find the correct spot to put the element
        while (curr != null && curr.compareTo(toInsert) < 0) {
            prev = curr;
            curr = curr.next;

        }
        // insert the element     
        if(prev == null) { // insertint top
            toInsert.next = top;
            top = toInsert;
        } else { // inserting in the middle
            prev.next = toInsert;
            toInsert.next = curr;
        } 

    }

    public String toString() {
        Node curr = top;
        String result = "";
        if(isEmpty()) { result = "Empty List"; }
        else {
            result = "<<";
            while(curr != null) {
                result += " " + curr.data;
                curr = curr.next;
            }
            result += " >>";
        }
        return result;
    }

    public void printInOrder() {
        System.out.print("<<");
        printInOrder(top);
        System.out.println(" >>");
    }

    private void printInOrder(Node curr) {
      
        if(curr != null) { // recursive case
            System.out.print(" " + curr.data);
            printInOrder(curr.next);
        } // base case do nothing
    }

    public void printInReverse() {
        System.out.print("<<");
        printInReverse(top);
        System.out.println(" >>");
    }

    public void printInReverse(Node curr) {
        if(curr != null) { // recursive case
            printInReverse(curr.next);
            System.out.print(" " + curr.data);
        } // base case do nothing
    }

    class Node {
        Object data;
        Node next;

        public Node (Object obj) {
            this.data = obj;
            this.next = null;
        }

        public Node(Object obj, Node next) {
            this.data = obj;
            this.next = next;
        }

        public int compareTo(Node other) {
            int curr = (Integer)this.data;
            int otherInt = (Integer)other.data;
            return curr - otherInt;
        }
    }
}