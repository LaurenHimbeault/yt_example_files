public class Main {
    public static void main(String[] args) {
        LinkedList ordered = new LinkedList();
        System.out.println("Adding 6");
        ordered.orderedInsert(6);  
        //System.out.println(ordered);

        System.out.println("Adding -1");
        ordered.orderedInsert(-1);   
        //System.out.println(ordered);

        System.out.println("Adding 11");
        ordered.orderedInsert(11);   
        //System.out.println(ordered);

        System.out.println("Adding 7");
        ordered.orderedInsert(7);   
        //System.out.println(ordered);

        ordered.printInOrder();
        ordered.printInReverse();
    }
}
