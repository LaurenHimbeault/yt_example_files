public class Person {
	public String name;
	public int age;

	public Person() { // no return type, not even void and the method name matches the class
		name = "Newborn";
		age = 0;
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}



	public void haveBirthday() {
		age++;
	}

	public void changeName(String name) { // set the instance variables name to name
		this.name = name;
	}

	public void changeName() {
		this.name = "";
	}

	public String toString() {
		return "Name: " + name + "\n\tAge: " + age;
	}

}