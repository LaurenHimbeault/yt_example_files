public class BasicObjectExample1 {
	public static void main(String[] args) {
		Person morrigan = new Person(); 
		Person lamia = new Person("Lamia", 12);	

		// shows the memory address of the memory allocated for each object 
		System.out.println(morrigan);
		System.out.println(lamia);
		/*
		morrigan.name = "Morrigan";
		lamia.name = "Lamia";
		morrigan.age = 13;
		lamia.age = 12;
		lamia.haveBirthday(); // only affect's morrigans age
		
			String x = " hello";
			String y = "world";
			System.out.println(x.length()); // tells me length of hello, NOT world
		
		if(morrigan.age > lamia.age) {
			System.out.println(morrigan.name + " is older than " + lamia.name);
		}else if(lamia.age > morrigan.age) {
			System.out.println(lamia.name + " is older than " + morrigan.name);
		} else {
			System.out.println(lamia.name + " and " + morrigan.name + " are the same age");
		}
		System.out.println("Morrigan Object " + morrigan.name);
		morrigan.changeName("Barbie");
		System.out.println("After changeName(): Morrigan Object " + morrigan.name);
		
		morrigan.changeName("Morrigan");
		System.out.println("Print Information in Objects");
		System.out.println(morrigan);
		System.out.println(lamia);

		Object obj = new Object();
		System.out.println(obj);
		*/

	}
}